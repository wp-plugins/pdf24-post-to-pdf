
PDF24.org Wordpress Plugin

ENGLISH
- Add this plugin to your wordpress plugin folder
- Enable the plugin in plugin section in wordpress 



GERMAN
- Kopiere dieses Plugin in den Plugin-Ordner von Wordpress
- Aktiviere das Plugin im Pluginbereich von wordpress