
PDF24.org Wordpress Sidebar Plugin

GERMAN:
- Kopiere die Datei pdf24.php in das benutzte Template-Verzeichnis
- F�ge die den untenstehenden Code an der Stelle in der sidebar.php hinzu, wo die Konvertierungsbox erscheinen soll


ENGLISH:
- Copy the file pdf24.php to your used theme directory
- insert the following code to the place in the file where the conversion box should appear



CODE F�R DIE SIDEBAR.PHP

<!-- Start pdf24.org sidebar plugin -->
<?php include (TEMPLATEPATH . '/pdf24.php'); ?>
<!-- End pdf24.org sidebar plugin -->